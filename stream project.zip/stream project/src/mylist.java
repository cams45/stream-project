import java.util.ArrayList;
import java.util.List;

public class mylist {
    protected List names;


    mylist() {

    }

    public void list(ArrayList<String> names){
        names.add("cams");
        names.add("carma");
        names.add("celest");
        names.add("caren");
        names.add("cane");
        names.add("crock");
        names.add("casey");
        names.add("john");
        names.add("jerry");

    }

    public void tostring(){
        System.out.print(names);
    }
}
