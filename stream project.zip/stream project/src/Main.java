import java.io.File;
import java.io.IOException;
import java.lang.reflect.Array;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class Main {

    public static void main(String[] args) throws IOException {
        System.out.println("Hello World!");
        mylist mylist = new mylist();
        String[] names1 = new String[]{"tim", "tale", "tonya", "tonny", "tony", "trill", "tremm", "john", "jerry", "joana"};




        System.out.println(
        IntStream
                .range(1,100)
                .skip(50)
                .sum());

        Stream.of("ave","cams","jeff")
                .sorted()
                .findAny()
                .ifPresent(System.out::println);

       Arrays.stream(names1)
                .filter(x -> x.startsWith("j"))
                .sorted()
                .forEach(System.out::println);

       Arrays.stream(new int[] {2,4,6,8,10})
               .map(x-> x* x)
               .average()
               .ifPresent(System.out::println);

       List<String> people = Arrays.asList("cock","John","cams","Jordan","Jaboc","michael","angie","steave","derrick");
               people
                       .stream()
                       .map(String::toLowerCase)
                       .filter(x -> x.startsWith("j"))
                       .forEach(System.out::println);

        System.out.println(new File("bands").getAbsolutePath());

               Stream<String> bands1 = Files.lines(Paths.get("C:\\Users\\camer\\IdeaProjects\\stream project\\src\\bands"));
               bands1
               .sorted()
               .filter(x -> x.length() > 13)
               .forEach(System.out::println);
               bands1.close();
               System.out.print("=========================================================\n");

              List<String> bands2 = Files.lines(Paths.get("C:\\Users\\camer\\IdeaProjects\\stream project\\src\\bands"))
              .filter(x-> x.contains("m"))
                .collect(Collectors.toList());
              bands2.forEach(System.out::println);

              System.out.print("=========================================================\n");
              Stream<String> rows1 = Files.lines(Paths.get("C:\\Users\\camer\\IdeaProjects\\stream project\\src\\data.txt"));
              int rowCount = (int ) rows1
                      .map(x -> x.split(","))
                      .filter(x -> x.length == 3)
                      .count();
              System.out.print(rowCount + "rows.\n");
              rows1.close();

              System.out.print("=========================================================\n");

              Stream<String> rows2 = Files.lines(Paths.get("C:\\Users\\camer\\IdeaProjects\\stream project\\src\\data.txt"));
              rows2
                      .map(x -> x.split(","))
                      .filter(x -> x.length == 3)
                      .filter(x -> Integer.parseInt(x[1]) > 15)
                      .forEach(x -> System.out.println(x[0] + "  " + x[1] + " " + x[2]));
              rows2.close();
    }


}
